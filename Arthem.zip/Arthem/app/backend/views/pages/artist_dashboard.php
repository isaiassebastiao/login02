<link rel="stylesheet" href="../../../frontend/public/css/index.css">

<main>
    <section class="artist_dashboard-main-section">
        <section class="side-bar">
            <ul>
                <li>
                    <a href=""></a>
                </li>
            </ul>
        </section>
    </section>
</main>