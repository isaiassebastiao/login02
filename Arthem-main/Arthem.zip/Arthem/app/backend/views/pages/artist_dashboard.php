<link rel="stylesheet" href="../../../frontend/public/css/pages/artist_dashboard.css">
<body>
    <header class="topo">
    <h1>Arthem</h1>
    <span>Painel do Artista</span>
    </header>

    <main class="container">
        <aside class="sidebar">
            <button class="active">Minhas Obras</button>
            <button>Publicar Obra</button>
        </aside>

        <section class="conteudo">
            <h2>Minhas Obras</h2>

            <table>
                <thead>
                    <tr>
                    <th>Obra</th>
                    <th>Título</th>
                    <th>Preço</th>
                    <th>Status</th>
                    <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><img src="obra1.png"></td>
                        <td>Memórias do Deserto</td>
                        <td>AOA 150.000</td>
                        <td class="ativo">Ativa</td>
                        <td>
                            <button class="ver">Ver</button>
                            <button class="editar">Editar</button>
                            <button class="excluir">Excluir</button>
                        </td>
                    </tr>
                    <tr>
                        <td><img src="obra2.png"></td>
                        <td>Ritmos de Luanda</td>
                        <td>AOA 120.000</td>
                        <td class="ativo">Ativa</td>
                        <td>
                            <button class="ver">Ver</button>
                            <button class="editar">Editar</button>
                            <button class="excluir">Excluir</button>
                        </td>
                    </tr>
                    <tr>
                        <td><img src="obra3.png"></td>
                        <td>Silêncio Africano</td>
                        <td>AOA 180.000</td>
                        <td class="inativo">Oculta</td>
                        <td>
                            <button class="ver">Ver</button>
                            <button class="editar">Editar</button>
                            <button class="excluir">Excluir</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </section>
    </main>   
</body>